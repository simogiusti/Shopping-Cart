import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  // Assicurati che l'URL corrisponda a quello del backend
  private apiUrl = 'http://localhost:3000/api/carrello';

  constructor(private http: HttpClient) { }

  // get del carrello
  getCarrello(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  // aggiungi un prodotto al carrello
  aggiungiAlCarrello(prodotto: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, prodotto);
  }

  // rimuovi un prodotto dal carrello
  rimuoviDalCarrello(id: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`);
  }
}
