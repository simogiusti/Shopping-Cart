const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// connessione MongoDB
mongoose.connect("mongodb://localhost:27017/shopping_cart", {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log("MongoDB Connesso"))
.catch(err => console.error("Errore di connessione:", err));

// schema prodotti
const ProductSchema = new mongoose.Schema({
    id: Number,
    nome: String,
    prezzo: Number
});

const Product = mongoose.model("Product", ProductSchema, 'prodotti');

// ottenere i prodotti
app.get("/api/prodotti", async (req, res) => {
  try {
    const prodotti = await Product.find();
    res.json(prodotti);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// aggiungere un prodotto al carrello
app.post("/api/carrello", async (req, res) => {
    try {
        const nuovoProdotto = new Prodotto(req.body);
        await nuovoProdotto.save();
        res.json(nuovoProdotto);
    } catch(err) {
        res.status(500).json({ error: err.message });
    }
});

// rimuovere un prodotto dal carrello
app.delete("/api/carrello/:id", async (req, res) => {
    try {
        await Prodotto.findByIdAndDelete(req.params.id);
        res.json({ message: "Prodotto rimosso" });
    } catch(err) {
        res.status(500).json({ error: err.message });
    }
});

app.listen(3000, () => console.log("Server avviato su http://localhost:3000"));
