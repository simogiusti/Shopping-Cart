import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProdottiService {
  private prodotti = [
    { id: 1, nome: 'Amerì', prezzo: 2 },
    { id: 2, nome: 'AOC Q24G2A QHD 24inches 165hz', prezzo: 200 },
    { id: 3, nome: 'Galaxy Buds FE', prezzo: 59.99 }
  ];
  
  constructor() { }

  getProdotti() {
    return this.prodotti;
  }
}
