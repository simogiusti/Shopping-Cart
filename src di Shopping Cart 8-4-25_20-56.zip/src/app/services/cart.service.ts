import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private carrello: any[] = [];
  private cartItemCount = new BehaviorSubject<number>(0);
  cartItemCount$ = this.cartItemCount.asObservable(); 

  constructor() { }

  aggiungiAlCarrello(prodotto: any) {
    this.carrello.push(prodotto);
    this.cartItemCount.next(this.carrello.length);
  }

  getCarrello() {
    return this.carrello;
  }

  rimuoviDalCarrello(prodotto: any) {
    const index = this.carrello.indexOf(prodotto);
    if (index > -1) {
      this.carrello.splice(index, 1);
      this.cartItemCount.next(this.carrello.length); 
    }
  }

  getCarrelloCount() {
    return this.cartItemCount$;
  }
}
