import { Component } from '@angular/core';
import { CartService } from '../../services/cart.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-carrello',
  imports: [CommonModule],
  templateUrl: './carrello.component.html',
  styleUrl: './carrello.component.scss'
})
export class CarrelloComponent {
  carrello: any[] = [];

  constructor(private cartService: CartService) {}

  ngOnInit() {
    this.carrello = this.cartService.getCarrello();
  }

  rimuoviDalCarrello(prodotto: any) {
    this.cartService.rimuoviDalCarrello(prodotto);
    this.carrello = this.cartService.getCarrello();
  }
  
}
